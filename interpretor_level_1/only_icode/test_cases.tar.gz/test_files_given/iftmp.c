main()
{
	int a = 3;
	int b = 4;
	int c;

	c = a > 2?a:b;
}
