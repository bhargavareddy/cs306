int a;
main()
{
	int b = 4;
	a = 3;

	a = a > b;
}
