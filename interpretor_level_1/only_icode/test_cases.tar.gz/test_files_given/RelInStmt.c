main()
{
	int a = 3;
	a = a > 2;
	if (a)
		a = 6;
	else
		a = 4;
}
