int a;
int b;
main()
{
	int c = 10;
	int f = 3;
	int d = 6;
	int e = 8;

	a = f < d;
	b = d <= c;
	if (c > b <= a != e)
	{
		c = e != d;
		d = f > e;
	}
	else if (c < e != d >= 9)
	{
		a = d >= e == f;
		b = b >= a;
	}
	else
		a = 4;
}
